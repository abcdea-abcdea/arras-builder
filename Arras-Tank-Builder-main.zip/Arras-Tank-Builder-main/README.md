# Arras-Tank-Builder
A visual editor for creating tanks in arras.io private servers.

# Credits
- **DogeisCut** - Project Creator/Lead
- **maxnest0x0** - Helped a ton with getting guns to draw
- **z46-dev** - Made [arras-template](https://github.com/z46-dev/arras-template), allowed me to make this accurate
- **IBlobTouch** - Made [iblobtouch.github.io](https://github.com/iblobtouch/iblobtouch.github.io), main inspiration
- **Momentum Studios** - litterally arras.io

# Adding Soon
- Turrets
- More properties for guns
- Advanced settings
- fixing shoot settings
- Finishing the gun dropdown
- Gun presets
- Importing tanks
- toggle buttons for every property instead of it being automatic
